package com.fashion.amai.DateTime.codec;

public enum Type {
    CALENDAR, TIME
}
