package com.fashion.amai.interfaces;

public interface MyDesignCheckoutInterface {
    void hideTotal();

}
