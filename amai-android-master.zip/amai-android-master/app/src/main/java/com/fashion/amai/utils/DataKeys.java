package com.fashion.amai.utils;

public class DataKeys {

    //merchant type keys
    public static String MERCHANT_DESIGNER = "designer";
    public static String MERCHANT_BOUTIQUE = "boutique";
    public static String MERCHANT_DESIGN_HOUSES = "design-house";
    public static String PRODUCT = "product";

    public static String[] MTYPE = new String[]{MERCHANT_BOUTIQUE,MERCHANT_DESIGNER, MERCHANT_DESIGN_HOUSES};
}
