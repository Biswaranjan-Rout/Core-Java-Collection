package com.fashion.amai.adapter;

import android.view.View;

interface CustomViewHolder {
    void onClick(View view);
}
