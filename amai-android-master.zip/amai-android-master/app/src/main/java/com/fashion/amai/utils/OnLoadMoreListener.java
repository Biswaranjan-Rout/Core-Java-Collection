package com.fashion.amai.utils;

/**
 * Created by S.Shahini on 8/8/16.
 * callback for notify view when user reached to list ends.
 */
public interface OnLoadMoreListener {
    void onLoadMore();
}
