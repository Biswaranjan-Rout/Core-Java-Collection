package com.fashion.amai.DateTime.helper;

import java.util.Calendar;

public interface PicoListener {
    void result(Calendar calendar);
}
