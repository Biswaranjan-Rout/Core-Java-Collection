package com.fashion.amai.interfaces;

public interface UpdateCheckoutInterface {

    void updateTotal(int price, int discount);


}
