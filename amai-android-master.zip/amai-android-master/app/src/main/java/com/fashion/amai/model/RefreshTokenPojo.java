package com.fashion.amai.model;

public class RefreshTokenPojo {
    String status;
    String message;
    String token;

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getToken() {
        return token;
    }
}
