package com.amai.AgentApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
