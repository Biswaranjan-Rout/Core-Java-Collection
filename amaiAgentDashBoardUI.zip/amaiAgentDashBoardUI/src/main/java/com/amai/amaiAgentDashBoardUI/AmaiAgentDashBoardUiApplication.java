package com.amai.amaiAgentDashBoardUI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmaiAgentDashBoardUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmaiAgentDashBoardUiApplication.class, args);
	}

}
